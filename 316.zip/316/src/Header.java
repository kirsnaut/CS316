class header extends TreeNode
{
	funName function_name; // cannot be null
	ParameterList parameter_list; // can be null (when there are no parameters)
	
	header (funName n, ParameterList params)
	{
		function_name = n;
		parameter_list = params;
	}
	
	void printParseTree(String indent)
	{
		String indent1 = indent + " ";
		
		LexAnalyzer.displayln(indent + indent.length() + " <header>");
		function_name.printParseTree(indent1);
		
		if (parameter_list != null)
			parameter_list.printParseTree(indent1);
		else
			LexAnalyzer.displayln(indent1 + indent1.length() + " <parameter list>");
	}	
}
