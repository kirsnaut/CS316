
class funName extends TreeNode
{
	String val;
	funName(String name)
	{
		val=name;
	}
	
	void printParseTree(String indent)
	{
		LexAnalyzer.displayln(indent + indent.length() + " <fun name> " + val);

	}
}



