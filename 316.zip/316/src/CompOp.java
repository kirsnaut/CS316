import java.util.HashMap;

abstract class CompOp extends FunOp
{
}

class Comp_Eq extends CompOp
{
	void printParseTree(String indent)
	{
		LexAnalyzer.displayln(indent + indent.length() + " =");
	}
	
	Val Eval(HashMap<String,Val> state) { return  new IdVal("=");}
}

class Comp_Gt extends CompOp
{
	void printParseTree(String indent)
	{
		LexAnalyzer.displayln(indent + indent.length() + " >");
	}
	
	Val Eval(HashMap<String,Val> state) { return  new IdVal(">");}

}
class Comp_Ge extends CompOp
{
	void printParseTree(String indent)
	{
		LexAnalyzer.displayln(indent + indent.length() + " >=");
	}
	
	Val Eval(HashMap<String,Val> state) { return  new IdVal(">=");}

}
class Comp_Lt extends CompOp
{
	void printParseTree(String indent)
	{
		LexAnalyzer.displayln(indent + indent.length() + " <");
	}
	
	Val Eval(HashMap<String,Val> state) { return  new IdVal("<");}

}
class Comp_Le extends CompOp
{
	void printParseTree(String indent)
	{
		LexAnalyzer.displayln(indent + indent.length() + " <=");
	}
	
	Val Eval(HashMap<String,Val> state) { return  new IdVal("<=");}

}
