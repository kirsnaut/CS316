class ParameterList extends TreeNode
{
	String id;
	ParameterList list;
	
	ParameterList (String param, ParameterList params)
	{
		id = param;
		list = params;
	}
	
	void printParameters(String indent)
	{
		LexAnalyzer.displayln(indent + indent.length() + " " + id);
		if (list != null)
			list.printParameters(indent);
	}
	
	void printParseTree(String indent)
	{
		String indent1 = indent + " ";
		
		LexAnalyzer.displayln(indent + indent.length() + " <parameter list>");
		printParameters(indent1);
	}
}
