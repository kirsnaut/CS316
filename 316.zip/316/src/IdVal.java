class IdVal extends Val
{
	String val;

	IdVal(String i)
	{
		val = i;
	}

	public String toString()
	{
		return val+"";
	}

	Val cloneVal()
	{
		return new IdVal(val);
	}

	double floatVal()
	{
		return 0;
	}
	
	boolean isZero()
	{
		return val == null;
	}

	@Override
	boolean isNumber() {
		// TODO Auto-generated method stub
		return false;
	}
}