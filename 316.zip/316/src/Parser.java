/*Name: Kirsten Pevidal
 *ID: 23560808
* Top-down Parser
* Based on: http://picasso.cs.qc.cuny.edu/cs316/ParseArith.java
* 
*/

public class Parser extends LexAnalyzer
{

	/**
	* <fun def list> -> <fun def>|<fun def><fun def list>
	*/
	public static FunDefList readFunDefList()
	{
		FunDef fundef = readFunDef(); 
		if (a != -1 )
		{	
			FunDefList fundeflist = readFunDefList();
			return new FunDefList(fundef,fundeflist);
			
		}	
		else
			return new FunDefList(fundef,null);
	}

	/**
	* <fun def> -> <header> <exp> 
	*/
	public static FunDef readFunDef()
	{
		//header(indent);
		
		header head = readHeader();
		//getToken();
		if (state == State.LBrace)
		{
			getToken();     // discard {
			//exp(indent);
			Exp exp = readExp();
			if (state == State.RBrace)
			{
				getToken(); // discard }
				return new FunDef(head,exp);
			}
			else
			{
				//display(indent);
				errorMsg("}");
				//displayln("");
			}
		}
		else
		{
			//display(indent);
			errorMsg("{");
			//displayln("");
		}
		displayln("");
		return new FunDef(head,null);
	}

	/**
	* <header> -> <fun name> "{" <parameter list> "}"
	*/
	public static header readHeader()
	{
		
		funName funname = readFunName();
		getToken();
		ParameterList paramlist = readParameterList();
		//parameter_list(indent);
		return new header(funname,paramlist);
	}

	/**
	* <fun name> -> <id>
	*/
	public static funName readFunName()
	{
		//displayln(indent + (indent.length()/TAB.length()) + " <fun name> " + t);
		funName funName = new funName(t);
		//getToken();
		return funName;
	}

	/**
	* <parameter list> -> empty string | <id> <parameter list>
	*/
	public static ParameterList readParameterList()
	{
			if(state == State.Id || state == state.Int || state == State.nHolder || 
					state == State.If_I || 
					state == State.Then_T || state == State.Then_Th || state == State.Then_The ||
					state == State.Else_E || state == State.Else_El || state == State.Else_Els ||
					state == State.Or_O ||
					state == State.And_A || state == State.And_An ||
					state == State.Not_No||
					state == State.Pair_P|| state == State.Pair_Pa|| state == State.Pair_Pai||
					state ==  State.First_F ||state == State.First_Fi || state == State.First_Fir || state == State.First_Firs || 
					state == State.Second_S || state == State.Second_Se|| state == State.Second_Sec|| state == State.Second_Seco|| state == State.Second_Secon|| 
				    state == State.Nil_Ni )
		      		                       
			{
				String hold = t;
				getToken();
				ParameterList list = readParameterList();
				return new ParameterList(hold,list);
			}
			else
				return null; //empty string
	}

	/**
	* <Exp> ->  <Id> | <Int> | <Float> | <FloatE> | <FloatF> | <Nil> | '(' <fun exp> ')' | 'if' <exp> 'then' <exp> 'else' <exp>
	* */
	public static Exp readExp()
	{
		switch (state)
		{
			case Id:
				if (state == State.Id)
				{

					String hold = t;
					getToken();
					return new Exp_Id (hold);
					
				} 
				
			case nHolder:
				if (state == State.nHolder)
				{
					String hold = t;
					getToken();
					return new Exp_Id (hold);
				} 
				
				
			case Int:
				if (state == State.Int)
				{
					String hold = t;
					getToken();
					return new Exp_Int (hold);
				}    
				
			case Period:
				if (state == State.Period)
				{
					String hold = t;
					getToken();
					return new Exp_Id (hold);
				}
				
			case Float:
				if (state == State.Float)
				{
					String hold = t;
					getToken();
					return new Exp_Float (hold);
				}
			case FloatE:
				if ( state == State.FloatE)
				{
					String hold = t;
					getToken();
					return new Exp_Float (hold);
				}
			case FloatF:
				if ( state == State.FloatF)
				{
					String hold = t;
					getToken();
					return new Exp_Float (hold);
				}
			case If_I:
				if ( state == State.If_I)
				{
					String hold = t;
					getToken();
					return new Exp_Id (hold);
				}
			case Then_T:
				if ( state == State.Then_T)
				{
					String hold = t;
					getToken();
					return new Exp_Id (hold);
				}
			case Then_Th:
				if ( state == State.Then_Th)
				{
					String hold = t;
					getToken();
					return new Exp_Id (hold);
				}
			case Then_The:
				if ( state == State.Then_The)
				{
					String hold = t;
					getToken();
					return new Exp_Id (hold);
				}
			case Else_E:
				if ( state == State.Else_E)
				{
					String hold = t;
					getToken();
					return new Exp_Id (hold);
				}
			case Else_El:
				if ( state == State.Else_El)
				{
					String hold = t;
					getToken();
					return new Exp_Id (hold);
				}
			case Else_Els:
				if ( state == State.Else_Els)
				{
					String hold = t;
					getToken();
					return new Exp_Id (hold);
				}
			case Or_O:
				if ( state == State.Or_O)
				{
					String hold = t;
					getToken();
					return new Exp_Id (hold);
				}
			case And_A:
				if ( state == State.And_A)
				{
					String hold = t;
					getToken();
					return new Exp_Id (hold);
				}
			case And_An:
				if ( state == State.And_An)
				{
					String hold = t;
					getToken();
					return new Exp_Id (hold);
				}
			case Not_No:
				if ( state == State.Not_No)
				{
					String hold = t;
					getToken();
					return new Exp_Id (hold);
				}
			case Pair_P:
				if ( state == State.Pair_P)
				{
					String hold = t;
					getToken();
					return new Exp_Id (hold);
				}
			case Pair_Pa:
				if ( state == State.Pair_Pa)
				{
					String hold = t;
					getToken();
					return new Exp_Id (hold);
				}
			case Pair_Pai:
				if ( state == State.Pair_Pai)
				{
					String hold = t;
					getToken();
					return new Exp_Id (hold);
				}
			case First_F:
				if ( state == State.First_F)
				{
					String hold = t;
					getToken();
					return new Exp_Id (hold);
				}
			case First_Fi:
				if ( state == State.First_Fi)
				{
					String hold = t;
					getToken();
					return new Exp_Id (hold);
				}
			case First_Fir:
				if ( state == State.First_Fir)
				{
					String hold = t;
					getToken();
					return new Exp_Id (hold);
				}
			case First_Firs:
				if ( state == State.First_Firs)
				{
					String hold = t;
					getToken();
					return new Exp_Id (hold);
				}
			case Second_S:
				if ( state == State.Second_S)
				{
					String hold = t;
					getToken();
					return new Exp_Id (hold);
				}
			case Second_Se:
				if ( state == State.Second_Se)
				{
					String hold = t;
					getToken();
					return new Exp_Id (hold);
				}
			case Second_Sec:
				if ( state == State.Second_Sec)
				{
					String hold = t;
					getToken();
					return new Exp_Id (hold);
				}
			case Second_Seco:
				if ( state == State.Second_Seco)
				{
					String hold = t;
					getToken();
					return new Exp_Id (hold);
				}
			case Second_Secon:
				if ( state == State.Second_Secon)
				{
					String hold = t;
					getToken();
					return new Exp_Id (hold);
				}
			case Nil_Ni:
				if ( state == State.Nil_Ni)
				{
					String hold = t;
					getToken();
					return new Exp_Id (hold);
				}
				
			case Keyword_Nil:
				if (state == State.Keyword_Nil)
				{
					
					getToken();
					return new Exp_Nil();
				}
				
			case LParen:
				getToken(); // discard (
				FunExp funex = readFunExp();
				if (state != State.RParen)
				{
					errorMsg(")");
				}
				else
				{
					getToken(); // discard )
				}				
				return funex;
				
			case Keyword_If:
				getToken();
				Exp e1 = readExp();
				if (state != State.Keyword_Then)
				{
					errorMsg("then");
					return null;
				}				
				getToken (); // get exp
				Exp e2 = readExp ();			
				if (state != State.Keyword_Else)
				{
					errorMsg("else");
					return null;
				}				
				getToken (); // get exp
				Exp e3 = readExp ();		
				return new Exp_If (e1, e2, e3);
							
			case RBrace:
				 return null;
				//break;
		
			default:
				errorMsg("Id | Int | Float | FloatE | FloatF | Nil | '(' Fun Exp ')' | If exp Then exp Else exp");
				//getToken();
		}
		return null;
	}

	
	private static FunExp readFunExp()
	{
		FunOp funop = readFunOp();		
		ExpList xplist = readExpList();		
		return new FunExp(funop,xplist);
		
	}
	
	/*
	 *  <fun op> -> Id | "pair" | "first" | "second" | <arith op> | <bool op> | <comp op>
	 * */
	private static FunOp readFunOp()
	{
		switch (state)
		{
			case Id:
				String hold=t;
				getToken();
				return new FunOp_Id (hold);
				
			case nHolder:
				String hold1 =t;
				getToken();
				return new FunOp_Id (hold1);
				
			case If_I:
				String hold2 = t;
				getToken();
				return new FunOp_Id (hold2);
			
			case Then_T:
				String hold3 = t;
				getToken();
				return new FunOp_Id (hold3);
				
			case Then_Th:
				String hold4 = t;
				getToken();
				return new FunOp_Id (hold4);

			case Then_The:

				String hold5 = t;
				getToken();
				return new FunOp_Id (hold5);
				
			case Else_E:

				String hold6 = t;
				getToken();
				return new FunOp_Id (hold6);

			case Else_El:

				String hold7 = t;
				getToken();
				return new FunOp_Id (hold7);
				
			case Else_Els:
				String hold8 = t;
				getToken();
				return new FunOp_Id (hold8);
				
			case Or_O:
				String hold9 = t;
				getToken();
				return new FunOp_Id (hold9);
				
			case And_A:
				String hold10 = t;
				getToken();
				return new FunOp_Id (hold10);
				
			case And_An:
				String hold11 = t;
				getToken();
				return new FunOp_Id (hold11);
				
			case Not_No:
				String hold12 = t;
				getToken();
				return new FunOp_Id (hold12);
				
			case Pair_P:
				String hold13 = t;
				getToken();
				return new FunOp_Id (hold13);
				
			case Pair_Pa:
				String hold14 = t;
				getToken();
				return new FunOp_Id (hold14);
				
			case Pair_Pai:
				String hold15 = t;
				getToken();
				return new FunOp_Id (hold15);
				
			case First_F:
				String hold16 = t;
				getToken();
				return new FunOp_Id (hold16);
				
			case First_Fi:
				String hold17 = t;
				getToken();
				return new FunOp_Id (hold17);
				
			case First_Fir:
				String hold18 = t;
				getToken();
				return new FunOp_Id (hold18);
				
			case First_Firs:
				String hold19 = t;
				getToken();
				return new FunOp_Id (hold19);
				
			case Second_S:
				String hold20 = t;
				getToken();
				return new FunOp_Id (hold20);
				
			case Second_Se:
				String hold21 = t;
				getToken();
				return new FunOp_Id (hold21);
				
			case Second_Sec:
				String hold22 = t;
				getToken();
				return new FunOp_Id (hold22);
				
			case Second_Seco:
				String hold23 = t;
				getToken();
				return new FunOp_Id (hold23);
				
			case Second_Secon:
				String hold24 = t;
				getToken();
				return new FunOp_Id (hold24);
				
			case Nil_Ni:
				String hold25 = t;
				getToken();
				return new FunOp_Id (hold25);
				
			case Keyword_Pair:
				getToken();
				return new FunOp_pair ();
			case Keyword_First:
				getToken();
				return new FunOp_first();
			case Keyword_Second:
				getToken();
				return new FunOp_second();
				
			case Add:
				getToken();
				return new Arith_Plus ();
			case Sub:
				getToken();
				return new Arith_Sub();
			case Mul:
				getToken();
				return new Arith_Mul ();
			case Div:
				getToken();
				return new Arith_Div ();
			case Keyword_Or:
				getToken();
				return new Bool_Or();
			case Keyword_And:
				getToken();
				return new Bool_And ();
			case Keyword_Not:
				getToken();
				return new Bool_Not ();
			case Gt:
				getToken();
				return new Comp_Gt ();
			case Ge:
				getToken();
				return new Comp_Ge ();
			case Le:
				getToken();
				return new Comp_Le ();
			case Lt:
				getToken();
				return new Comp_Lt ();
			case Eq:
				getToken();
				return new Comp_Eq ();
				
			default:
				errorMsg ("Id | Pair | First | Second | Bool Op | Arith Op | Comp Op");
		}
		return null;
			
	}
	
	/*
	 * <Exp List> -> <Exp> | <Exp> <Exp List>
	 * */
	public static ExpList readExpList()
	{
			if(state == State.Id || state == State.nHolder || state == State.Int || state == State.Float || state == State.FloatE || state == State.FloatF
					|| state == State.Period || state == State.Keyword_Nil || state == State.Keyword_If || state == State.Keyword_Then || state == State.Keyword_Else
					|| state == State.LParen || 
					state == State.If_I || 
					state == State.Then_T || state == State.Then_Th || state == State.Then_The ||
					state == State.Else_E || state == State.Else_El || state == State.Else_Els ||
					state == State.Or_O ||
					state == State.And_A || state == State.And_An ||
					state == State.Not_No||
					state == State.Pair_P|| state == State.Pair_Pa|| state == State.Pair_Pai||
					state ==  State.First_F ||state == State.First_Fi || state == State.First_Fir || state == State.First_Firs || 
					state == State.Second_S || state == State.Second_Se|| state == State.Second_Sec|| state == State.Second_Seco|| state == State.Second_Secon|| 
				    state == State.Nil_Ni)
			{
				//exp(indent);
				Exp exp = readExp();
				ExpList xl = readExpList();
				return new ExpList(exp,xl);
			}
			return null;
			//getToken();
			//displayln("");
	} 


	public static void errorMsg(String expected)
	{
				display(t + ": Syntax error, unexpected symbol where " + expected
					+ " expected");
				empty();

	} 

	public static void main(String args[])
	{
		setIO(args[0], args[1]);
		getToken();
		//readFunDefList();
		FunDefList test = readFunDefList();
		test.printParseTree("");
		closeIO();
	}
}
