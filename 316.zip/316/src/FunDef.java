class FunDef extends TreeNode
{
	header hheader; // cannot be null
	Exp exp; // cannot be null
	
	FunDef (header h, Exp e)
	{
		hheader = h;
		exp = e;
	}
	
	void printParseTree(String indent)
	{
		String indent1 = indent + " ";
		
		LexAnalyzer.displayln(indent + indent.length() + " <fun def>");
		hheader.printParseTree (indent1);
		exp.printParseTree (indent1);
		LexAnalyzer.displayln("");
	}	
}
