/* CS316 Project 1
 * Name: Kirsten Pevidal
 * ID: 23560808
 * 
 * LexAnalyzer.java : The lexical analyzer program is to read an input text file, extract the tokens in it, 
 * and write them out one by one on separate lines. Each token should be flagged with its category. 
 * The output should be sent to an output text file. Whenever invalid tokens are found, error messages should be printed, 
 * and the reading process should continue.
 * 
 * Based on: http://picasso.cs.qc.cuny.edu/cs316/LexArith.java,
 * 			 http://picasso.cs.qc.cuny.edu/cs316/IO.java
 */

import java.io.*;

public class LexAnalyzer{
    
    public enum State 
    { 
      // non-final states

            Start,
            Period,
            E,
            EPlusMinus,

      // final states

            Id, 		//ID
            Int,		//Integer
            Float,		//Float
            FloatE,		//FloatE
            FloatF,		//FloatF
            Add,		//Add
            Sub,		//Subtract
            Mul,		//Multiply
            Div,		//Divide
            Lt,			//Less than
            Le,			//Less than Equal
            Gt,			//Greater than
            Ge,			//Greater than Equal
            Eq,			//Equal
            LParen,		//Left Parenthesis
            RParen,		//Right Parenthesis
            LBrace,		//Left Brace Bracket
            RBrace,		//Right Brace Bracket

            nHolder,	/*Hold State for input where first token is 'N', we need a separate state to check
            			 *because it has 3 possible next states: Not, Nil, ID*/
            
            /*States for 'If' keyword*/
            If_I,
            Keyword_If,
            
            /*States for 'Then' keyword*/
            Then_T,
            Then_Th,
            Then_The,
            Keyword_Then,
            
            /*States for 'Else' keyword*/
            Else_E,
            Else_El,
            Else_Els,
            Keyword_Else,
            
            /*States for 'Or' keyword*/
            Or_O,
            Keyword_Or,
            
            /*States for 'And' keyword*/
            And_A,
            And_An,
            Keyword_And,
            
            /*States for 'Not' keyword*/
            Not_No,
            Keyword_Not,
            
            /*States for 'Pair' keyword*/
            Pair_P,
            Pair_Pa,
            Pair_Pai,
            Keyword_Pair,
            
            /*States for 'First' keyword*/
            First_F,
            First_Fi,
            First_Fir,
            First_Firs,
            Keyword_First,
            
            /*States for 'Second' keyword*/
            Second_S,
            Second_Se,
            Second_Sec,
            Second_Seco,
            Second_Secon,
            Keyword_Second,
            
            /*States for 'Nil' keyword*/
            Nil_Ni,
            Keyword_Nil,
                       
            /*Undefined State*/
            UNDEF
    }
    
    protected static int a; // holds current input character
    private static char c; // used to convert the variable "a" to 
                           // the char type whenever necessary
    
    
    public static String t; // holds extracted token
    public static State state; // the current state of the FA
    
   
    private static BufferedReader inStream;
    private static PrintWriter outStream;

    /*  Returns the next character on the input stream.
     */
    private static int getNextChar() {
        try {
                return inStream.read();
        } catch(IOException e) {
            e.printStackTrace();
            return -1;
        }
    } 

    
    private static int getChar() {
            int i = getNextChar();
            while ( Character.isWhitespace((char) i) )
                    i = getNextChar();
            return i;
    } // end getChar


    /*Based on LexArith.java*/
    private static int driver() {
        State nextState; // the next state of the FA

        t = "";
        state = State.Start;
        if ( Character.isWhitespace((char) a) ) {
            a = getChar(); // get the next non-whitespace character
            if ( a == -1 ) // end-of-stream is reached
                return -1;
        }

        while ( a != -1 ) // while "a" is not end-of-stream
        {
            c = (char) a;
            nextState = nextState( state, c );
            if ( nextState == State.UNDEF ) // The FA will halt.
            {
                if ( isFinal(state) )
                    return 1; // valid token extracted
                else // "c" is an unexpected character
                {
                    t = t+c;
                    a = getNextChar();
                    return 0; // invalid token found
                }
            }
            else // The FA will go on.
            {
                    state = nextState;
                    t = t+c;
                    a = getNextChar();
            }
        }

        // end-of-stream is reached while a token is being extracted

        if ( isFinal(state) )
            return 1; // valid token extracted
        else
            return 0; // invalid token found
    } // end driver

    
    /*  Returns the next state of the FA given the current state and input char;
     *  if the next state is undefined, UNDEF is returned.
     *   
     *  In the original, CASE statement is used. here I used If-else for consistency in the rest of the codes.
     *  
     */    
    private static State nextState(State s, char c) {
        if ( s == State.Start ) {
            if ( Character.isLetter(c) ) {
                if ( c == 'i' ) return State.If_I;              // token is 'i'
                else if ( c == 't' ) return State.Then_T; 		// token is 't'
                else if ( c == 'e' ) return State.Else_E;       // token is 'e'
                else if ( c == 'o' ) return State.Or_O;         // token is 'o'
                else if ( c == 'a' ) return State.And_A;     	// token is 'a'
                else if ( c == 'n' ) return State.nHolder;   	// token is 'n'
                else if ( c == 'p' ) return State.Pair_P;       // token is 'p'
                else if ( c == 'f' ) return State.First_F;      // token is 'f'
                else if ( c == 's' ) return State.Second_S;     // token is 's'
                //else if ( c == 'n' ) return State.Nil_N;       
                else	
                    return State.Id;							// token is a letter not listed above
            }
            
            else if ( Character.isDigit(c) ) return State.Int;  // token is a digit
            else if ( c == '+' ) return State.Add;				// token is '+'
            else if ( c == '-' ) return State.Sub;				// token is '-'
            else if ( c == '*' ) return State.Mul;				// token is '*'
            else if ( c == '/' ) return State.Div;				// token is '/'
            else if ( c == '(' ) return State.LParen;			// token is '('
            else if ( c == ')' ) return State.RParen;			// token is ')'
            else if ( c == '{' ) return State.LBrace;			// token is '{'
            else if ( c == '}' ) return State.RBrace;			// token is '}'
            else if ( c == '=' ) return State.Eq;				// token is '='
            else if ( c == '<' ) return State.Lt;				// token is '<='
            else if ( c == '>' ) return State.Gt;				// token is '>='
            else if ( c == '.' ) return State.Period;			// token is '.'
            else return State.UNDEF;        
        } 
        
        //Add | Positive
        //If followed by a digit, send to integer
        //if followed by a period, sent to float
        //else undefined
        else if ( s == State.Add ) {
            if ( Character.isDigit(c) )
                return State.Int;
            else if ( c == '.' )
                return State.Period;
            else
                return State.UNDEF;
        }
        
        //Subtract | Negative
        //If followed by a digit, send to integer
        //if followed by a period, sent to float
        //else undefined
        else if ( s == State.Sub ) {
            if ( Character.isDigit(c) )
                return State.Int;
            else if ( c == '.' )
                return State.Period;   
            else
                return State.UNDEF;
        }
        
        //ID
        else if ( s == State.Id ) {
            if ( Character.isLetterOrDigit(c) )
                return State.Id;
         
            else
                return State.UNDEF;
        }
        
        //Integer
        else if ( s == State.Int ) {
            if ( Character.isDigit(c) )
                return State.Int;
            else if ( c == 'e' || c == 'E' )
                return State.E;
            else if (c == 'f' || c == 'F')
            	return State.FloatF;
            else if ( c == '.' )
                return State.Float;
            else if (Character.isLetter(c))
            	return State.Id;
            else
                return State.UNDEF;
        }
        
        //Period
        else if ( s == State.Period ) {
            if ( Character.isDigit(c) )
                return State.Float;
            else if ( c == 'e' || c == 'E' )
                return State.E;
            else if (c == 'f' || c == 'F')
            	return State.FloatF;
            else
                return State.UNDEF;
        }
        
        //float
        else if ( s == State.Float ) {
            if ( Character.isDigit(c) )
                return State.Float;
            else if ( c == 'e' || c == 'E' )
                return State.E;
            else if (c == 'f' || c == 'F')
            	return State.FloatF;
            else
                return State.UNDEF;
        }
        
        //Exponent
        else if ( s == State.E ) {
            if ( Character.isDigit(c) )
                return State.FloatE;
            else if ( c == '+' || c == '-' )
                return State.EPlusMinus;
            else if (c == 'f' || c == 'F')
            	return State.FloatF;
            else
                return State.UNDEF;
        }
        
        //Exponent+-
        else if ( s == State.EPlusMinus ) {
            if ( Character.isDigit(c) )
                return State.FloatE;
            else if (c == 'f' || c == 'F')
            	return State.FloatF;
            else
                return State.UNDEF;
        }
        
        //Float E
        else if ( s == State.FloatE ) {
            if ( Character.isDigit(c) )
                return State.FloatE;
            else if (c == 'f' || c == 'F')
            	return State.FloatF;
            else return State.UNDEF;
        }   
        //FloatF
        else if ( s == State.FloatF )
        {         
                return State.UNDEF;
        }
   //-----------------------------------------------------------------  
        //Equal
        else if ( s == State.Eq ) {
            if ( c == '=' )
                return State.Eq;
            else
                return State.UNDEF;
        } 
        //Return Less than Equal '<='
        else if ( s == State.Lt ) {
            if ( c == '=' ) 
                return State.Le;
            else
                return State.UNDEF;
        } 
        //Return Greater than Equal '>='
        else if ( s == State.Gt ) {
            if ( c == '=' )
                return State.Ge;
            else
                return State.UNDEF;
        } 
   //-----------------------------------------------------------------     
     // if-i
        else if ( s == State.If_I ) {             
            if ( c == 'f' ) return State.Keyword_If;
            else if (Character.isLetterOrDigit(c)) return State.Id;
            else            return State.UNDEF;
        } 
     // if-if
        else if ( s == State.Keyword_If ) {
            if ( Character.isLetterOrDigit(c) ) return State.Id;
            else return State.UNDEF;
        } 
   //-----------------------------------------------------------------     
     // Then-t 
        else if ( s == State.Then_T ) {             
	        if ( c == 'h' ) return State.Then_Th;
	        else if (Character.isLetterOrDigit(c)) return State.Id;
            else            return State.UNDEF;
	        
	    } 
     // Then-th
	     else if ( s == State.Then_Th ) {
	        if (c == 'e' ) return State.Then_The;
	        else if (Character.isLetterOrDigit(c)) return State.Id;
            else            return State.UNDEF;
	    } 
     // Then-the
	     else if ( s == State.Then_The ) {
		        if (c == 'n' ) return State.Keyword_Then;
		        else if (Character.isLetterOrDigit(c)) return State.Id;
	            else            return State.UNDEF;
		}
     // Then-then   
	     else if ( s == State.Keyword_Then ) {
	            if ( Character.isLetterOrDigit(c) ) return State.Id;
	            else return State.UNDEF;
	    }
   //----------------------------------------------------------------- 
           
     // else-e   
        else if ( s == State.Else_E ) {           
            if ( c == 'l' ) return State.Else_El;
            else if (Character.isLetterOrDigit(c)) return State.Id;
            else            return State.UNDEF;
        } 
     // else-el   
        else if ( s == State.Else_El ) {          
            if ( c == 's' ) return State.Else_Els;
            else if (Character.isLetterOrDigit(c)) return State.Id;
            else            return State.UNDEF;
        } 
     // else-els   
        else if ( s == State.Else_Els ) {         
            if ( c == 'e' ) return State.Keyword_Else;
            else if (Character.isLetterOrDigit(c)) return State.Id;
            else            return State.UNDEF;
        } 
     // else-else   
        else if ( s == State.Keyword_Else ) {
            if ( Character.isLetterOrDigit(c) ) return State.Id;
            else return State.UNDEF;

        } 
   //-----------------------------------------------------------------         
     // Or-o   
        else if ( s == State.Or_O ) {           
            if ( c == 'r' ) return State.Keyword_Or;
            else if (Character.isLetterOrDigit(c)) return State.Id;
            else            return State.UNDEF;
        }
     // Or-or  
        else if ( s == State.Keyword_Or ) {          
        	if ( Character.isLetterOrDigit(c) ) return State.Id;
        	else return State.UNDEF;
        }
   //-----------------------------------------------------------------             
     // And-a   
        else if ( s == State.And_A ) {           
            if ( c == 'n' ) return State.And_An;
            else if (Character.isLetterOrDigit(c)) return State.Id;
            else            return State.UNDEF;
        }
     // And-an     
        else if ( s == State.And_An ) {           
            if ( c == 'd' ) return State.Keyword_And;
            else if (Character.isLetterOrDigit(c)) return State.Id;
            else            return State.UNDEF;
        }
     // And-and    
        else if ( s == State.Keyword_And ) {           
        	if ( Character.isLetterOrDigit(c) ) return State.Id;
        	else return State.UNDEF;
        }
    //-----------------------------------------------------------------  
     // if current token is 'n'    
        else if ( s == State.nHolder ) {           
            if ( c == 'o' ) return State.Not_No; //if next token is 'o', go to Not-no
            else if (c == 'i') return State.Nil_Ni; //if next token is 'i, go to Nil-ni
            else  if(Character.isLetterOrDigit(c))        return State.Id; //else go to ID
            else return State.UNDEF;
        }
        
    //-----------------------------------------------------------------         
     // Not-no   
        else if ( s == State.Not_No ) {           
            if ( c == 't' ) return State.Keyword_Not;
            else if (Character.isLetterOrDigit(c)) return State.Id;
            else            return State.UNDEF;
        }
     // Not-not    
        else if ( s == State.Keyword_Not ) {           
        	if ( Character.isLetterOrDigit(c) ) return State.Id;
        	else return State.UNDEF;
        }
    //-----------------------------------------------------------------
     // Pair-P   
        else if ( s == State.Pair_P) {           
            if ( c == 'a' ) return State.Pair_Pa;
            else if (Character.isLetterOrDigit(c)) return State.Id;
            else            return State.UNDEF;
        }
     // Pair-Pa
        else if ( s == State.Pair_Pa ) {           
            if ( c == 'i' ) return State.Pair_Pai;
            else if (Character.isLetterOrDigit(c)) return State.Id;
            else            return State.UNDEF;
        }
     // Pair-Pai     
        else if ( s == State.Pair_Pai ) {           
            if ( c == 'r' ) return State.Keyword_Pair;
            else if (Character.isLetterOrDigit(c)) return State.Id;
            else            return State.UNDEF;
        }
     // Pair-Pair   
        else if ( s == State.Keyword_Pair ) {           
        	if ( Character.isLetterOrDigit(c) ) return State.Id;
            else return State.UNDEF;
        }
    //----------------------------------------------------------------- 
     // First-f  
        else if ( s == State.First_F) {           
            if ( c == 'i' ) return State.First_Fi;
            else if (Character.isLetterOrDigit(c)) return State.Id;
            else            return State.UNDEF;
        }
     // First-fi
        else if ( s == State.First_Fi) {           
            if ( c == 'r' ) return State.First_Fir;
            else if (Character.isLetterOrDigit(c)) return State.Id;
            else            return State.UNDEF;
        }
     // First-fir
        else if ( s == State.First_Fir) {           
            if ( c == 's' ) return State.First_Firs;
            else if (Character.isLetterOrDigit(c)) return State.Id;
            else            return State.UNDEF;
        }
     // First-firs
        else if ( s == State.First_Firs) {           
            if ( c == 't' ) return State.Keyword_First;
            else if (Character.isLetterOrDigit(c)) return State.Id;
            else            return State.UNDEF;
        }
     // First-first
        else if ( s == State.Keyword_First ) {           
        	if ( Character.isLetterOrDigit(c) ) return State.Id;
            else return State.UNDEF;
        }
    //-----------------------------------------------------------------        
     // Second-s  
        else if ( s == State.Second_S) {           
            if ( c == 'e' ) return State.Second_Se;
            else if (Character.isLetterOrDigit(c)) return State.Id;
            else            return State.UNDEF;
        }
     // Second-se
        else if ( s == State.Second_Se) {           
            if ( c == 'c' ) return State.Second_Sec;
            else if (Character.isLetterOrDigit(c)) return State.Id;
            else            return State.UNDEF;
        }
     // Second-sec
        else if ( s == State.Second_Sec) {           
            if ( c == 'o' ) return State.Second_Seco;
            else if (Character.isLetterOrDigit(c)) return State.Id;
            else            return State.UNDEF;
        }
     // Second-seco   
        else if ( s == State.Second_Seco) {           
            if ( c == 'n' ) return State.Second_Secon;
            else if (Character.isLetterOrDigit(c)) return State.Id;
            else            return State.UNDEF;
        }
     // Second-secon   
        else if ( s == State.Second_Secon) {           
            if ( c == 'd' ) return State.Keyword_Second;
            else if (Character.isLetterOrDigit(c)) return State.Id;
            else            return State.UNDEF;
        }
     // Second-second     
        else if ( s == State.Keyword_Second ) {           
        	if ( Character.isLetterOrDigit(c) ) return State.Id;
            else return State.UNDEF;
        }
    //-----------------------------------------------------------------               
     // Nil-ni  
        else if ( s == State.Nil_Ni) {           
            if ( c == 'l' ) return State.Keyword_Nil;
            else if (Character.isLetterOrDigit(c)) return State.Id;
            else            return State.UNDEF;
        }
     // Nil-nil   
        else if ( s == State.Keyword_Nil ) {           
        	if ( Character.isLetterOrDigit(c) ) return State.Id;
            else return State.UNDEF;
        }
              
       else
            return State.UNDEF;
    } 
    /**Based on  LexArith.java*/
    private static boolean isFinal(State state) {
        return ( state.compareTo(State.Id) >= 0 );  
    }

    /**
     * Extract the next token using the driver of the FA.
     * If an invalid token is found, issue an error message.
    */
    public static void getToken() {
        int i = driver();
      //  if ( i == 0 )
        //    displayln(t + "  -- Invalid Token\n");
    } // end getToken

    public static void display(String s) {
        outStream.print(s);
    }

    public static void displayln(String s) {
        outStream.println(s);
    }
    
    public static void empty()
    {
    	outStream.close();
    }

    /** Based on IO.java
     *  Sets the input and output streams to "inFile" and "outFile", respectively.
     *  Also sets the current input character "a" to the first character on the input stream.
     */
    public static void setIO(String inFile, String outFile)
    {
        try {
            inStream = new BufferedReader( new FileReader(inFile) );
            outStream = new PrintWriter( new FileOutputStream(outFile) );
            a = inStream.read();
        }
        catch(FileNotFoundException e) {
            e.printStackTrace();
        }
        catch(IOException e) {
            e.printStackTrace();
        }
    }

    public static void closeIO() {
        try {
            inStream.close();
            outStream.close();
        } catch(IOException e) {
            e.printStackTrace();
        }
    } 
       
    public static void main(String[] args)
    {

        setIO( args[0], args[1] );
        
        int i;
        
        //print results to ouput file
        while ( a != -1 ) 
        {
            i = driver(); // extract the next token
            if ( i == 1 )
                displayln( t+"   : "+state.toString() ); //current token is valid
            else if ( i == 0 )
                displayln( t+"  : Lexical Error, invalid token" ); //current token is an invalid token
        } 
        
        System.out.println("Check output txt."); //result will be printed in an ouput.txt
        closeIO();
    } 
    
}