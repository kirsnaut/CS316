import java.util.*;

public abstract class Interpreter extends Parser
{
	public static void main(String args[])
	
	/* 
	   argv[0]: source program file containing function definitions
	   argv[1]: lexical/syntactical error messages for the source program in argv[0]
	   argv[2]: single expression to be evaluated
	   argv[3]: lexical/syntactical error messages for the expression in argv[2]
	 
	   The evaluation result and runtime errors will be displayed on the terminal.
	*/
	
	{
		setIO( args[0], args[1] );
		//setLex();
		
		getToken();
		FunDefList funDefList = readFunDefList();
		if ( ! t.isEmpty() )
			errorMsg("empty");
		else
		{
			closeIO();
			setIO( args[2], args[3] );
			getToken();
			Exp exp = readExp();
			if ( ! t.isEmpty() )
				displayln(t + "  -- unexpected symbol");
			else
			{
				try {
				Val v = exp.Eval(new HashMap<String,Val>());  // evaluate the given expression
				if ( v != null )
					System.out.println( v.toString() ); 
				}
				catch(Exception e)
				{
					System.out.println("Error: Empty input text file");
					LexAnalyzer.displayln("Error: Empty input text file");// display the value on the terminal
				}
			}				
		}

		closeIO();
	}
}