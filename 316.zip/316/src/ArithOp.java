import java.util.HashMap;

abstract class ArithOp extends FunOp
{
}

class Arith_Plus extends ArithOp
{
	ExpList xl;
	
	void printParseTree(String indent)
	{
		LexAnalyzer.displayln(indent + indent.length() + " +");

	}

	@Override
	Val Eval(HashMap<String, Val> state) {
		// TODO Auto-generated method stub
		return  new IdVal("+");
	}
	

}

class Arith_Sub extends ArithOp
{
	void printParseTree(String indent)
	{
		LexAnalyzer.displayln(indent + indent.length() + " -");
	}
	
	Val Eval(HashMap<String,Val> state) {
		return  new IdVal("-");
	}

}

class Arith_Mul extends ArithOp
{
	void printParseTree(String indent)
	{
		LexAnalyzer.displayln(indent + indent.length() + " *");
	}
	
	Val Eval(HashMap<String,Val> state) {
		return  new IdVal("*");
		}
}

class Arith_Div extends ArithOp
{
	void printParseTree(String indent)
	{
		LexAnalyzer.displayln(indent + indent.length() + " /");
	}
	
	Val Eval(HashMap<String,Val> state) {
		return  new IdVal("/");
	}
}

