import java.util.HashMap;

public class FunExp extends Exp
{
	FunOp op; // cannot be null
	ExpList exp_list; // can be null
	
	
	FunExp (FunOp o, ExpList l)
	{
		op = o;
		exp_list = l;
	}
	
	void printParseTree(String indent)
	{
		String indent1 = indent + " ";
		LexAnalyzer.displayln(indent + indent.length() + " <exp> ");
		LexAnalyzer.displayln(indent1 + indent1.length() + " <fun exp>");
		indent1= indent1 + " ";
		op.printParseTree(indent1);
		
		if (exp_list != null)
			exp_list.printParseTree(indent1);		
	}
	
	Val Eval(HashMap<String,Val> state) {
		try {
		
		
		Val def=  op.Eval(state);
		if(def.toString().equalsIgnoreCase("+"))
		{
			if(exp_list==null)
			{
				return new IntVal(0);
			}
			else if(exp_list.AddEval(state)==null)
			{
				System.out.println(" Error: Addition by non-digit.");
				LexAnalyzer.displayln("Error: Addition by non-digit.");
				return null;
			}
			else
				return exp_list.AddEval(state);
		}
		else if(def.toString().equalsIgnoreCase("-"))
		{
			if(exp_list==null)
			{
				return new IntVal(0);
			}
			if(exp_list.MulEval(state)==null)
			{
				System.out.println(" Error: subtraction by non-digit");
				LexAnalyzer.displayln("Error: division by zero");
				return null;
			}
			else
			return (exp_list.SubEval(state));
		}
		else if(def.toString().equalsIgnoreCase("*"))
		{
			if(exp_list==null)
			{
				return new IntVal(1);
			}
			if(exp_list.MulEval(state)==null)
			{
				System.out.println(" Error: Multiplication by non-digit");
				LexAnalyzer.displayln("Error: division by zero");
				return null;
			}
			else
			return (exp_list.MulEval(state));
		}
		else if(def.toString().equalsIgnoreCase("/"))
		{
			if(exp_list==null)
			{
				return new IntVal(1);
			}
			if(exp_list.DivEval(state)==null)
			{
				System.out.println(" Error: division by non-digit/zero");
				LexAnalyzer.displayln("Error: division by zero");
				return null;
			}
			else
			return (exp_list.DivEval(state));
		}
		
		else if (def.toString().equalsIgnoreCase("And"))
		{
			if(exp_list==null)
			{
				return new BoolVal(true);
			}
			if(exp_list.AndEval(state)==null)
			{
				System.out.println(" Error: And Operation by non-boolean values");
				LexAnalyzer.displayln("Error: division by zero");
				return null;
			}
			//return exp_list.AndEval(state);
			return exp_list.AndEval(state);
		}
		
		else if (def.toString().equalsIgnoreCase("Or"))
		{
			if(exp_list==null)
			{
				return new BoolVal(false);
			}
			if(exp_list.OrEval(state)==null)
			{
				System.out.println(" Error: Or Operation by non-boolean values");
				LexAnalyzer.displayln("Error: division by zero");
				return null;
			}
			return (exp_list.OrEval(state));
		}
		
		else if (def.toString().equalsIgnoreCase("Not"))
		{
			if(exp_list==null)
			{
				System.out.println("Error: not operator missing argument");
				LexAnalyzer.displayln("Error: not operator missing argument");
				return null;
			}
			if(exp_list.NotEval(state)==null)
			{
				System.out.println("Error: cannot perform operation to non-boolean value.");
				LexAnalyzer.displayln("Error: cannot perform operation to non-boolean value.");
				return null;
			}
			return (exp_list.NotEval(state));
		}
		
		else if (def.toString().equalsIgnoreCase("="))
		{
			if(exp_list==null)
			{
				return new BoolVal(true);
			}
			return (exp_list.EqEval(state));
		}
		
		else if (def.toString().equalsIgnoreCase("<"))
		{
			if(exp_list==null)
			{

				return new BoolVal(true);
			}
			if(exp_list.LtEval(state)==null)
			{
				System.out.println("Error: cannot perform operation to nondigit");
				LexAnalyzer.displayln("Error: cannot perform operation to nondigit");
				return null;
			}
			return (exp_list.LtEval(state));
		}
		
		else if (def.toString().equalsIgnoreCase("<="))
		{
			if(exp_list==null)
			{

				return new BoolVal(true);
			}
			if(exp_list.LeEval(state)==null)
			{
				System.out.println("Error: cannot perform operation to nondigit");
				LexAnalyzer.displayln("Error: cannot perform operation to nondigit");
				return null;
			}
			return (exp_list.LeEval(state));
		}
		
		else if (def.toString().equalsIgnoreCase(">"))
		{
			if(exp_list==null)
			{
				
				return new BoolVal(true);
			}
			if(exp_list.GtEval(state)==null)
			{
				System.out.println("Error: cannot perform operation to nondigit");
				LexAnalyzer.displayln("Error: cannot perform operation to nondigit");
				return null;
			}
			return (exp_list.GtEval(state));
		}
		
		else if (def.toString().equalsIgnoreCase(">="))
		{
			if(exp_list==null)
			{

				return new BoolVal(true);
			}
			if(exp_list.GeEval(state)==null)
			{
				System.out.println("Error: Greater Than Equal operation to non-digit");
				LexAnalyzer.displayln("Error: Greater Than Equal operation  to non-digit");
				return null;
			}
			return (exp_list.GeEval(state));
		}
		else if(def.toString().equalsIgnoreCase("pair"))
		{	
			if(exp_list==null)
			{
				System.out.println("Error: pair operator invalid arguments");
				LexAnalyzer.displayln("Error: pair operator invalid arguments");
				return null;
			}
			
			/*if(exp_list.PairEval(state)==null||exp_list.pair(state))
			{
				System.out.println("Error: pair operator invalid arguments");
				LexAnalyzer.displayln("Error: pair operator invalid arguments");
				return null;
			}*/
			
			if(Fun_Exp.pairs==0)
				return exp_list.PairEval(state);
			
			else if (Fun_Exp.pairs==2)
				return exp_list.SecondEval(state);
			if(exp_list.FirstEval(state)==null)
			{
			}
			else return exp_list.FirstEval(state);
		}
		
		else if(def.toString().equalsIgnoreCase("first"))
		{
			if(exp_list==null)
			{
				System.out.println("Error: first operator missing argument");
				LexAnalyzer.displayln("Error: first operator missing argument");
				return null;
			}

			if(exp_list.Eval(state).toString().contains("pair"))
			{
			Fun_Exp.pairs=1;
			
			return exp_list.Eval(state);
			}
			else
			{
				System.out.println("Error: first operator invalid argument");
				LexAnalyzer.displayln("Error: first operator invalid argument");
				return null;
			}

		}
		
		else if(def.toString().equalsIgnoreCase("second"))
		{
			if(exp_list==null)
			{
				System.out.println("Error: second operator missing argument");
				LexAnalyzer.displayln("Error: second operator missing argument");
				return null;
			}
			if(exp_list.Eval(state).toString().contains("pair"))
			{
			Fun_Exp.pairs=2;
			
			return exp_list.Eval(state);
			}
			else
				
				{
					System.out.println("Error: second operator invalid argument");
					LexAnalyzer.displayln("Error: second operator invalid argument");
					return null;
				}

		}
		

		return null;
		}catch(Exception e)
		{
		System.out.println("Error: Empty statement");
		LexAnalyzer.displayln("Error: Empty Statement");
		return null;
		}
		
		// assign the value eVal to id
	
	/* For practical reason of efficiency, the error state is not implemented.
	   Rather, the error state is implicitly assumed whenever Eval returns null representing
	   the runtime error value. */
		}

}
