

abstract class TreeNode
{
	abstract void printParseTree(String indent);
}
