public class PairVal extends Val{

	Val first;
	Val second;
	String pairs;
	@Override
	Val cloneVal() {
		// TODO Auto-generated method stub
		return null;
	}
	
	PairVal(Val st, Val nd)
	{
		first=st;
		second=nd;
	}

	public String toString()
	{
		return "pair("+first.toString()+", "+second.toString()+")";
	}

	
	@Override
	double floatVal() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	boolean isNumber() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	boolean isZero() {
		// TODO Auto-generated method stub
		return false;
	}

}