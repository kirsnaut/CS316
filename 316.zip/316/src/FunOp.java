import java.util.HashMap;

abstract class FunOp extends TreeNode
{
	abstract Val Eval(HashMap<String, Val> hashMap);
}

class FunOp_Id extends FunOp {

	String id;

	FunOp_Id(String ident)
	{
		id = ident;
	}

	void printParseTree(String indent)
	{
		LexAnalyzer.displayln(indent + indent.length() + " " + id);
	}
	
		Val Eval(HashMap<String,Val> state)
		{

			return new IdVal(id);
			
			// assign the value eVal to id
		
		/* For practical reason of efficiency, the error state is not implemented.
		   Rather, the error state is implicitly assumed whenever Eval returns null representing
		   the runtime error value. */
		}

		
	
}

class FunOp_pair extends FunOp
{
	void printParseTree(String indent)
	{
		LexAnalyzer.displayln(indent + indent.length() + " pair");
	}
	
	Val Eval(HashMap<String,Val> state) { return  new IdVal("Pair");}
}

class FunOp_first extends FunOp
{
	void printParseTree(String indent)
	{
		LexAnalyzer.displayln(indent + indent.length() + " first");
	}
	
	Val Eval(HashMap<String,Val> state) { return new IdVal("first");}
}

class FunOp_second extends FunOp
{
	void printParseTree(String indent)
	{
		LexAnalyzer.displayln(indent + indent.length() + " second");
	}
	
	Val Eval(HashMap<String,Val> state) { return  new IdVal("second");}
}
