import java.util.HashMap;

class ExpList extends TreeNode
{
	 Exp exp; // cannot be null
	 ExpList list; // can be null
	
	ExpList (Exp e)
	{
		exp = e;
	}
	
	ExpList (Exp e, ExpList l)
	{
		exp = e;
		list = l;
	}
	
	Exp firstExp() {
		return exp;
	}

	Exp secondExp() {
		return list.firstExp();
	}
	
	ExpList tailExpList() {
		return list;
	}
	
	void printTerms(String indent)
	{
		exp.printParseTree(indent);
		if (list != null)
			list.printTerms(indent);
	}
	
	void printParseTree(String indent)
	{
		String indent1 = indent + ' ';
		
		LexAnalyzer.displayln(indent + indent.length() + " <exp list>");

		printTerms(indent1);
	}
	
	Val Eval(HashMap<String, Val> state) {
		if (exp == null && list == null)
			return null;
		Val expVal = exp.Eval(state);

		if (list == null) {
		
			return expVal.cloneVal();
		}
		
		Val expListVal = list.Eval(state);
		
		if (expVal == expListVal) {
			return expVal.cloneVal();
		} else {
			return null;
		}
	}
	
	 Val AddEval(HashMap<String, Val> state)
	 {
		 
		//System.out.println("12");

			if (list == null)
			{
				try
				{
					if(isNumeric(exp.Eval(state).toString()))
					{
					if(exp.Eval(state).toString().contains("."))
						return new FloatVal(exp.Eval(state).floatVal());
					else
						return new IntVal((int)exp.Eval(state).floatVal());
					}
					else return null;
				}
				catch(Exception E)
				{
					return null;
				}

			}
			else
			{
				try
				{
					if(isNumeric(exp.Eval(state).toString())&&isNumeric(list.AddEval(state).toString()))
					{
					if(exp.Eval(state).toString().contains(".")||list.AddEval(state).toString().contains("."))
						return new FloatVal(exp.Eval(state).floatVal() + list.AddEval(state).floatVal());
					else 
						return new IntVal((int)exp.Eval(state).floatVal() + (int)list.AddEval(state).floatVal());
					}
					else
						return null;
				}
				catch(Exception e)
				{
					return null;
				}
				

			}
	}
	 
	 Val SubEval(HashMap<String, Val> state)
	 {
		 
		//System.out.println("12");
			if (list == null)
			{
			 	if((!isNumeric(exp.Eval(state).toString())))
			 	{
			 		return null;
			 	}
				if(exp.Eval(state).toString().contains("."))
				return new FloatVal(exp.Eval(state).floatVal());
				else
				return new IntVal((int)exp.Eval(state).floatVal());
			}
			else
			{
				try {
					if((!isNumeric(exp.Eval(state).toString())||(!isNumeric(list.SubEval(state).toString()))))
				 	{
				 		return null;
				 	}
				if(exp.Eval(state).toString().contains(".")||list.SubEval(state).toString().contains("."))
				return new FloatVal(exp.Eval(state).floatVal() - list.SubEval(state).floatVal());
				else
				return new IntVal((int)exp.Eval(state).floatVal() - (int)list.SubEval(state).floatVal());
				}
				catch(Exception e)
				{
					return null;
				}
			}
	} 
	
	 Val MulEval(HashMap<String, Val> state)
	 {

			if (list == null)
			{
			 	if((!isNumeric(exp.Eval(state).toString())))
			 	{
			 		return null;
			 	}
				if(exp.Eval(state).toString().contains("."))
				return new FloatVal(exp.Eval(state).floatVal());
				else
				return new IntVal((int)exp.Eval(state).floatVal());
			}

			else
			{

				try {
				 	if((!isNumeric(exp.Eval(state).toString())||(!isNumeric(list.MulEval(state).toString()))))
				 	{
				 		return null;
				 	}
				if(exp.Eval(state).toString().contains(".")||list.MulEval(state).toString().contains("."))
				return new FloatVal(exp.Eval(state).floatVal() * list.MulEval(state).floatVal());
				else
				return new IntVal((int)exp.Eval(state).floatVal() * (int)list.MulEval(state).floatVal());
				}
				catch(Exception e)
				{
					return null;
				}
			}
	}
	 
	 
	 
	 Val DivEval(HashMap<String, Val> state)
	 {

			if (list == null) {
			 	if((!isNumeric(exp.Eval(state).toString())))
			 	{
			 		return null;
			 	}
					if(exp.Eval(state).toString().contains("."))
					return new FloatVal(exp.Eval(state).floatVal());
					else
					return new IntVal((int)exp.Eval(state).floatVal());
			}

			else {
				try { // do the following if it is not division by zero
						if(exp.Eval(state).toString().contains(".")||list.DivEval(state).toString().contains("."))
						return new FloatVal(exp.Eval(state).floatVal() / list.DivEval(state).floatVal());
						else
						return new IntVal((int)exp.Eval(state).floatVal() / (int)list.DivEval(state).floatVal());
					}
				catch(Exception e)
					{
					return null; // if division by zero
				}
				
				

			}
	}
	 
	 Val AndEval(HashMap<String, Val> state)
	 {
		if(list==null)
		{

			if(exp.Eval(state).toString().equalsIgnoreCase("1")||(exp.Eval(state).toString().equalsIgnoreCase("0")))
			{
				return new BoolVal(exp.Eval(state).toString().equalsIgnoreCase("1"));
			}
			else if ((exp.Eval(state).toString().equalsIgnoreCase("true"))||(exp.Eval(state).toString().equalsIgnoreCase("false")))
			{
				return new BoolVal(exp.Eval(state).toString().equalsIgnoreCase("true"));
			}
		}
		else
		{	if(list.AndBoolDigit(state)!=null)
			{
				
			
			if((exp.Eval(state).toString().equalsIgnoreCase("0"))||(exp.Eval(state).toString().equalsIgnoreCase("1")))
			{
					if(list.AndBoolDigit(state).toString().equalsIgnoreCase("0")||(list.AndBoolDigit(state).toString().equalsIgnoreCase("1")))
					{
						return new BoolVal(exp.Eval(state).toString().equalsIgnoreCase("1") && 
						(list.AndBoolDigit(state).toString().equalsIgnoreCase("1")));
					}
					else if(list.AndBoolDigit(state).toString().equalsIgnoreCase("false")||(list.AndBoolDigit(state).toString().equalsIgnoreCase("true")))
					{
						return new BoolVal(exp.Eval(state).toString().equalsIgnoreCase("1") && 
						(list.AndBoolDigit(state).toString().equalsIgnoreCase("true")));
					}
	
			}
			
			else 
			{
				if ((exp.Eval(state).toString().equalsIgnoreCase("true"))||(exp.Eval(state).toString().equalsIgnoreCase("false")))
				{
					if(list.AndBoolDigit(state).toString().equalsIgnoreCase("false")||(list.AndBoolDigit(state).toString().equalsIgnoreCase("true")))
					return new BoolVal(exp.Eval(state).toString().equalsIgnoreCase("true") && 
							(list.AndEval(state).toString().equalsIgnoreCase("true")));
					else if((list.AndBoolDigit(state).toString().equalsIgnoreCase("0")||(list.AndBoolDigit(state).toString().equalsIgnoreCase("1"))))
							{
								return new BoolVal(exp.Eval(state).toString().equalsIgnoreCase("true") && 
								(list.AndBoolDigit(state).toString().equalsIgnoreCase("1")));
							}
					
				}
				
			}
			}
		else return null;
	
		}
		return null;
	}
	 
	 Val AndBoolDigit(HashMap<String, Val> state)
	 {
		 if(list==null)
		 {
			 return exp.Eval(state);
		 }
		 else
		 {	if(list.AndBoolDigit(state)!=null)
		 {
			if(exp.Eval(state).toString().equalsIgnoreCase("1")&&(list.AndBoolDigit(state).toString().equalsIgnoreCase("1")))
					return new IdVal("1");
			else if(exp.Eval(state).toString().equalsIgnoreCase("1")&&(list.AndBoolDigit(state).toString().equalsIgnoreCase("true")))
				return new IdVal("1");
			else if(exp.Eval(state).toString().equalsIgnoreCase("true")&&(list.AndBoolDigit(state).toString().equalsIgnoreCase("1")))
				return new IdVal("1");
			else if(exp.Eval(state).toString().equalsIgnoreCase("true")&&(list.AndBoolDigit(state).toString().equalsIgnoreCase("true")))
				return new IdVal("1");
			else if(exp.Eval(state).toString().equalsIgnoreCase("0")&&(list.AndBoolDigit(state).toString().equalsIgnoreCase("1")))
				return new IdVal("0");
			else if(exp.Eval(state).toString().equalsIgnoreCase("0")&&(list.AndBoolDigit(state).toString().equalsIgnoreCase("true")))
				return new IdVal("0");
			else if(exp.Eval(state).toString().equalsIgnoreCase("0")&&(list.AndBoolDigit(state).toString().equalsIgnoreCase("0")))
				return new IdVal("0");
			else if(exp.Eval(state).toString().equalsIgnoreCase("0")&&(list.AndBoolDigit(state).toString().equalsIgnoreCase("false")))
				return new IdVal("0");
			else if(exp.Eval(state).toString().equalsIgnoreCase("1")&&(list.AndBoolDigit(state).toString().equalsIgnoreCase("false")))
				return new IdVal("0");
			else if(exp.Eval(state).toString().equalsIgnoreCase("1")&&(list.AndBoolDigit(state).toString().equalsIgnoreCase("0")))
				return new IdVal("0");
			else if(exp.Eval(state).toString().equalsIgnoreCase("true")&&(list.AndBoolDigit(state).toString().equalsIgnoreCase("false")))
				return new IdVal("0");
			else if(exp.Eval(state).toString().equalsIgnoreCase("true")&&(list.AndBoolDigit(state).toString().equalsIgnoreCase("0")))
				return new IdVal("0");
			else if(exp.Eval(state).toString().equalsIgnoreCase("false")&&(list.AndBoolDigit(state).toString().equalsIgnoreCase("true")))
				return new IdVal("0");
			else if(exp.Eval(state).toString().equalsIgnoreCase("false")&&(list.AndBoolDigit(state).toString().equalsIgnoreCase("false")))
				return new IdVal("0");
			else if(exp.Eval(state).toString().equalsIgnoreCase("false")&&(list.AndBoolDigit(state).toString().equalsIgnoreCase("1")))
				return new IdVal("0");
			else if(exp.Eval(state).toString().equalsIgnoreCase("false")&&(list.AndBoolDigit(state).toString().equalsIgnoreCase("0")))
				return new IdVal("0");
			else return null;
		 }
		 else return null;
		 }
		
			 
	 }
	 
	 Val OrEval(HashMap<String, Val> state)
	 {
		if(list==null)
		{

			if(exp.Eval(state).toString().equalsIgnoreCase("1")||(exp.Eval(state).toString().equalsIgnoreCase("0")))
			{
				return new BoolVal(exp.Eval(state).toString().equalsIgnoreCase("1"));
			}
			else if ((exp.Eval(state).toString().equalsIgnoreCase("true"))||(exp.Eval(state).toString().equalsIgnoreCase("false")))
			{
				return new BoolVal(exp.Eval(state).toString().equalsIgnoreCase("true"));
			}
		}
		else
		{		 
			if(list.OrBoolDigit(state)!=null)
			{
				try {
				if((exp.Eval(state).toString().equalsIgnoreCase("0"))||(exp.Eval(state).toString().equalsIgnoreCase("1")))
				{
						if(list.OrBoolDigit(state).toString().equalsIgnoreCase("0")||(list.OrBoolDigit(state).toString().equalsIgnoreCase("1")))
						{
							return new BoolVal(exp.Eval(state).toString().equalsIgnoreCase("1") || 
							(list.OrBoolDigit(state).toString().equalsIgnoreCase("1")));
						}
						else if(list.OrBoolDigit(state).toString().equalsIgnoreCase("false")||(list.OrBoolDigit(state).toString().equalsIgnoreCase("true")))
						{
							return new BoolVal(exp.Eval(state).toString().equalsIgnoreCase("1") ||
							(list.OrBoolDigit(state).toString().equalsIgnoreCase("true")));
						}
						else return null;
		
				}
				else 
				{
					if ((exp.Eval(state).toString().equalsIgnoreCase("true"))||(exp.Eval(state).toString().equalsIgnoreCase("false")))
					{
						if(list.OrBoolDigit(state).toString().equalsIgnoreCase("false")||(list.OrBoolDigit(state).toString().equalsIgnoreCase("true")))
						return new BoolVal(exp.Eval(state).toString().equalsIgnoreCase("true") || 
								(list.OrEval(state).toString().equalsIgnoreCase("true")));
						else if((list.OrBoolDigit(state).toString().equalsIgnoreCase("0")||(list.OrBoolDigit(state).toString().equalsIgnoreCase("1"))))
								{
									return new BoolVal(exp.Eval(state).toString().equalsIgnoreCase("true") ||
									(list.OrBoolDigit(state).toString().equalsIgnoreCase("1")));
								}
						return null;
						
					}
					
				}
				}catch(Exception e)
				{
					return null;
				}
		
			}
			
			else return null;
		
		}
		return null;
	}
	 
	 Val OrBoolDigit(HashMap<String, Val> state)
	 {
		 if(list==null)
		 {
			 return exp.Eval(state);
		 }
		 else
		 {	
			 if(list.OrBoolDigit(state)!=null)
			 {
			if(exp.Eval(state).toString().equalsIgnoreCase("false")||(list.OrBoolDigit(state).toString().equalsIgnoreCase("1")))
					return new IdVal("1");
			if(exp.Eval(state).toString().equalsIgnoreCase("false")||(list.OrBoolDigit(state).toString().equalsIgnoreCase("true")))
				return new IdVal("1");
			if(exp.Eval(state).toString().equalsIgnoreCase("0")||(list.OrBoolDigit(state).toString().equalsIgnoreCase("1")))
				return new IdVal("1");
			if(exp.Eval(state).toString().equalsIgnoreCase("0")||(list.OrBoolDigit(state).toString().equalsIgnoreCase("true")))
				return new IdVal("1");
			if(exp.Eval(state).toString().equalsIgnoreCase("1")||(list.OrBoolDigit(state).toString().equalsIgnoreCase("1")))
				return new IdVal("1");
			if(exp.Eval(state).toString().equalsIgnoreCase("1")||(list.OrBoolDigit(state).toString().equalsIgnoreCase("0")))
				return new IdVal("1");
			if(exp.Eval(state).toString().equalsIgnoreCase("1")||(list.OrBoolDigit(state).toString().equalsIgnoreCase("true")))
				return new IdVal("1");
			if(exp.Eval(state).toString().equalsIgnoreCase("1")||(list.OrBoolDigit(state).toString().equalsIgnoreCase("false")))
				return new IdVal("1");
			if(exp.Eval(state).toString().equalsIgnoreCase("true")||(list.OrBoolDigit(state).toString().equalsIgnoreCase("true")))
				return new IdVal("1");
			if(exp.Eval(state).toString().equalsIgnoreCase("true")||(list.OrBoolDigit(state).toString().equalsIgnoreCase("0")))
				return new IdVal("1");
			if(exp.Eval(state).toString().equalsIgnoreCase("true")||(list.OrBoolDigit(state).toString().equalsIgnoreCase("1")))
				return new IdVal("1");
			if(exp.Eval(state).toString().equalsIgnoreCase("true")||(list.OrBoolDigit(state).toString().equalsIgnoreCase("false")))
				return new IdVal("1");

			else return new IdVal("0");
		 }
			 else return null;
		 }

		
			 
	 }
	 
	 
	 Val NotEval(HashMap<String, Val> state)
	 {
		{
			if(exp.Eval(state).toString().equalsIgnoreCase("true"))
				return new BoolVal(false);
			else if(exp.Eval(state).toString().equalsIgnoreCase("false"))
				return new BoolVal(true);
			else if(exp.Eval(state).toString().equalsIgnoreCase("0"))
				return new BoolVal(true);
			else if(exp.Eval(state).toString().equalsIgnoreCase("1"))
				return new BoolVal(false);
			else return null;
		}
		
	}
	 
	 Val EqEval(HashMap<String, Val> state)
	 {
		{
			if(list==null)
			{
				return new BoolVal(true);
			}
			else
			{ if(list.EqualEval(state)!=null)
				{
				if((isNumeric(exp.Eval(state).toString()) || isNumeric(list.EqualEval(state).toString())))
					return new BoolVal((exp.Eval(state).floatVal()==(list.EqualEval(state).floatVal())));
				else
				 return new BoolVal(exp.Eval(state).toString().equalsIgnoreCase(list.EqualEval(state).toString()));
				}
			else 
					return new BoolVal(false);
			}
		}
	 }
	 Val EqualEval(HashMap<String, Val> state)
	 {
		 if(list==null)
		 {
			 return exp.Eval(state);
		 }
		 else
		 {	if(list.EqualEval(state)!=null)
		 {
			 if((exp.Eval(state).toString().equalsIgnoreCase("true"))||(exp.Eval(state).toString().equalsIgnoreCase("false"))||
					 (list.EqualEval(state).toString().equalsIgnoreCase("false")||(list.EqualEval(state).toString().equalsIgnoreCase("true"))))
			 {
				 return null;
			 }
			 if((isNumeric(exp.Eval(state).toString()) || isNumeric(list.EqualEval(state).toString())))
			 {
				 if((exp.Eval(state).floatVal()==(list.EqualEval(state).floatVal())))
					return  exp.Eval(state);
				 else return null;
			 }
			else if(exp.Eval(state).toString().equalsIgnoreCase(list.EqualEval(state).toString()))
		 	{
				return exp.Eval(state);
		 			
		 	}
		 		else return null;
		 }
		 else return null;
		 }
			 
	 }
	 
	 Boolean eval=true;
	 Val LtEval(HashMap<String, Val> state)
	 {
		 if(list==null)
		 {
			 if(!isNumeric(exp.Eval(state).toString()))
				 return null;
			 return new BoolVal(true);
		 }
		 else
		 {
			 if(list.lessThan(state)!=null)
			 {
				 if((exp.Eval(state).toString().equalsIgnoreCase("true"))||(exp.Eval(state).toString().equalsIgnoreCase("false"))|| (!isNumeric(exp.Eval(state).toString()))||
						 (list.lessThan(state).toString().equalsIgnoreCase("false")||(list.lessThan(state).toString().equalsIgnoreCase("true")))||!isNumeric(list.lessThan(state).toString()))
				 {
					 return null;
				 }
				 else
				 return new BoolVal(exp.Eval(state).floatVal() < list.lessThan(state).floatVal());
			 }
			 else
				 return null;
		}

	}
	 
	 Val lessThan(HashMap<String, Val> state)
	 {
		 if(list==null)
		 {if(!isNumeric(exp.Eval(state).toString()))
			 return null;
			 return exp.Eval(state);
		 }
		 else
		 {

			 if(list.lessThan(state)!=null)
			 {
				 if((exp.Eval(state).toString().equalsIgnoreCase("true"))||(exp.Eval(state).toString().equalsIgnoreCase("false"))||
						 (list.lessThan(state).toString().equalsIgnoreCase("false")||(list.lessThan(state).toString().equalsIgnoreCase("true")))||!isNumeric(exp.Eval(state).toString())||!isNumeric(list.lessThan(state).toString()))
				 {
					 return null;
				 }
			 if(exp.Eval(state).floatVal() < list.lessThan(state).floatVal())
			 {
				 return exp.Eval(state);
			 }
			 else return new FloatVal(0);
			 }
			 else return null;
		 }
	 }

	 

	 Val LeEval(HashMap<String, Val> state)
	 {
		 if(list==null)
		 {
			 if(!isNumeric(exp.Eval(state).toString()))
				 return null;
			 return new BoolVal(true);
		 }
		 else
		 {
			 if(list.lessThanEqual(state)!=null)
			 {
			 if(!list.lessThanEqual(state).toString().equalsIgnoreCase("yer"))
			 {

			 if(!isNumeric(exp.Eval(state).toString())||!isNumeric(list.lessThanEqual(state).toString()))
				 return null;
			 else
			 return new BoolVal(exp.Eval(state).floatVal() <= list.lessThanEqual(state).floatVal());
			 }
			 else return new BoolVal(false);
			 }
			 return null;
		 }

	}
	 
	 Val lessThanEqual(HashMap<String, Val> state)
	 {
		 if(list==null)
		 {			 if(!isNumeric(exp.Eval(state).toString()))
			 return null;
			 return exp.Eval(state);
		 }
		 else
		 {

			 if(list.lessThanEqual(state)!=null)
			 {
				 if((exp.Eval(state).toString().equalsIgnoreCase("true"))||(exp.Eval(state).toString().equalsIgnoreCase("false"))||
						 (list.lessThanEqual(state).toString().equalsIgnoreCase("false")||(list.lessThanEqual(state).toString().equalsIgnoreCase("true")))||
						 !isNumeric(exp.Eval(state).toString())||!isNumeric(list.lessThanEqual(state).toString()))
				 {
					 return null;
				 }
				 else if(exp.Eval(state).floatVal() <= list.lessThanEqual(state).floatVal())
				 {
					 return exp.Eval(state);
				 }
				 else
					 return new IdVal("yer");

			 }
			 else return null;
		 }
	 }
	 
	
	 
	 Val GtEval(HashMap<String, Val> state)
	 {
		 if(list==null)
		 {
			 if(!isNumeric(exp.Eval(state).toString()))
				 return null;
			 return new BoolVal(true);
		 }
		 else
		 {

			 if(list.GreaterThan(state)!=null)
			 {
				 if(!list.GreaterThan(state).toString().equalsIgnoreCase("yer"))
				 {
					 if((exp.Eval(state).toString().equalsIgnoreCase("true"))||(exp.Eval(state).toString().equalsIgnoreCase("false"))|| (!isNumeric(exp.Eval(state).toString()))||
							 (list.GreaterThan(state).toString().equalsIgnoreCase("false")||(list.GreaterThan(state).toString().equalsIgnoreCase("true")))||!isNumeric(list.GreaterThan(state).toString()))
					 {
						 return null;
					 }
					 else
					 return new BoolVal(exp.Eval(state).floatVal() > list.GreaterThan(state).floatVal());
				 }
				 else return new BoolVal(false);
			 }
			 else
				 return null;
		}
		
	} 
	 
	 Val GreaterThan(HashMap<String, Val> state)
	 { 
		 if(list==null)
			 {
			 	if(!isNumeric(exp.Eval(state).toString()))
				 return null;
			 
				 return exp.Eval(state);
			 }
			 else
			 {
		
				 if(list.GreaterThan(state)!=null)
				 {
					 if((exp.Eval(state).toString().equalsIgnoreCase("true"))||(exp.Eval(state).toString().equalsIgnoreCase("false"))||
							 (list.GreaterThan(state).toString().equalsIgnoreCase("false")||(list.GreaterThan(state).toString().equalsIgnoreCase("true")))||!isNumeric(exp.Eval(state).toString())||!isNumeric(list.GreaterThan(state).toString()))
					 {
						 return null;
					 }	
				 if(exp.Eval(state).floatVal() > list.GreaterThan(state).floatVal())
				 {
					 return exp.Eval(state);
				 }
				 else return new IdVal("yer");
				 }
				 else return null;
			 }
	 }
	
	 Val GeEval(HashMap<String, Val> state)
	 {
		 if(list==null)
		 {
			 if(!isNumeric(exp.Eval(state).toString()))
				 return null;
			 return new BoolVal(true);
		 }
		 else
		 {

			 if(list.GreaterThanEqual(state)!=null)
			 {
				 if(!list.GreaterThanEqual(state).toString().equalsIgnoreCase("yer"))
				 {
					 if((exp.Eval(state).toString().equalsIgnoreCase("true"))||(exp.Eval(state).toString().equalsIgnoreCase("false"))|| (!isNumeric(exp.Eval(state).toString()))||
							 (list.GreaterThanEqual(state).toString().equalsIgnoreCase("false")||(list.GreaterThanEqual(state).toString().equalsIgnoreCase("true")))||!isNumeric(list.GreaterThanEqual(state).toString()))
					 {
						 return null;
					 }
					
					 else
					 return new BoolVal(exp.Eval(state).floatVal() >= list.GreaterThanEqual(state).floatVal());
				 }
				 else return new BoolVal(false);
			 }

			 else
				 return null;
		}
	}
	 
	 Val GreaterThanEqual(HashMap<String, Val> state)
	 {
		 if(list==null)
		 {
		 	if(!isNumeric(exp.Eval(state).toString()))
			 return null;
		 
			 return exp.Eval(state);
		 }
		 else
		 {
	
			 if(list.GreaterThanEqual(state)!=null)
			 {

				 if((exp.Eval(state).toString().equalsIgnoreCase("true"))||(exp.Eval(state).toString().equalsIgnoreCase("false"))||
						 (list.GreaterThanEqual(state).toString().equalsIgnoreCase("false")||(list.GreaterThanEqual(state).toString().equalsIgnoreCase("true")))
						 ||!isNumeric(exp.Eval(state).toString())||!isNumeric(list.GreaterThanEqual(state).toString()))
				 {
					 return null;
				 }	
				 
				 if(exp.Eval(state).floatVal() >= list.GreaterThanEqual(state).floatVal())
				 {
					 return exp.Eval(state);
				 }
				 else return new IdVal("yer");
			 }

				 
			 else return new IdVal("yer");
		
		 }

		
	}
	 
	 
	 Val PairEval(HashMap<String, Val> state)
	 {
		 
		//System.out.println("12");
			if (list == null)
			{
				System.out.println("Error: pair operator invalid arguments");
				LexAnalyzer.displayln("Error: pair operator invalid arguments");
				return null;
			}
			else if(list.list!=null)
			return null;
			else
				//return new PairVal(firstExp().Eval(state),secondExp().Eval(state));
				return new IdVal("pair("+firstExp().Eval(state).toString() +", "+secondExp().Eval(state).toString()+")");
	}
	 
	 Val FirstEval(HashMap<String, Val> state)
	 {
		// System.out.println(exp.Eval(state).toString());
		 Fun_Exp.pairs=0;
		 return exp.Eval(state);
		 
	}
	 
	 Val SecondEval(HashMap<String, Val> state)
	 {
		 //System.out.println(list.Eval(state).toString());
		 Fun_Exp.pairs=0;
		 return list.Eval(state);
	}
	
	 
	 public static boolean isNumeric(String strNum) {
		    if (strNum == null) {
		        return false;
		    }
		    try {
		        double d = Double.parseDouble(strNum);
		    } catch (NumberFormatException nfe) {
		        return false;
		    }
		    return true;
		}
	
	
	 

	
}
