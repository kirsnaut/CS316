
public class bo {

	public bo() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		System.out.println("Hilu Gudmurning!");

	}

}
