
public class NilVal extends Val{


	String val;

	NilVal(String dos)
	{
		val = dos;
	}

	public String toString()
	{
		return val+"";
	}
	
	Val cloneVal() {
		// TODO Auto-generated method stub
		return null;
	}


	double floatVal() {
		// TODO Auto-generated method stub
		return 0;
	}


	boolean isNumber() {
		// TODO Auto-generated method stub
		return false;
	}


	boolean isZero() {
		// TODO Auto-generated method stub
		return false;
	}

}