import java.util.HashMap;

abstract class Exp extends TreeNode
{
	abstract Val Eval(HashMap<String,Val> state);//change

}

class Exp_Id extends Exp {

	String id;

	Exp_Id(String ident)
	{
		id = ident;
	}

	void printParseTree(String indent)
	{
		String hold=indent +" ";
		LexAnalyzer.displayln(indent + indent.length() + " <exp> ");
		LexAnalyzer.displayln(hold + hold.length() + " " + id);
	}
	
	Val Eval(HashMap<String,Val> state) {

			return new IdVal(id);
			
			// assign the value eVal to id
		
		/* For practical reason of efficiency, the error state is not implemented.
		   Rather, the error state is implicitly assumed whenever Eval returns null representing
		   the runtime error value. */}
}

class Exp_Int extends Exp
{
	String value;

	Exp_Int(String n)
	{
		value = n;
	}

	void printParseTree(String indent)
	{
		String hold=indent +" ";
		LexAnalyzer.displayln(indent + indent.length() + " <exp> ");
		LexAnalyzer.displayln(hold + hold.length() + " " + value);
	}
	
	Val Eval(HashMap<String,Val> state) {return new IntVal(Integer.parseInt(value));}

}

class Exp_Float extends Exp
{
	String value;

	Exp_Float(String f)
	{
		value = f;
	}

	void printParseTree(String indent)
	{
		String hold=indent +" ";
		LexAnalyzer.displayln(indent + indent.length() + " <exp> ");
		LexAnalyzer.displayln(hold + hold.length() + " " + value);
	}
	
	Val Eval(HashMap<String,Val> state) {return new FloatVal(Float.parseFloat(value));}
}

class Exp_If extends Exp
{
	Exp expr1, expr2, expr3; 
	
	Exp_If (Exp e1, Exp e2, Exp e3)
	{
		expr1 = e1;
		expr2 = e2;
		expr3 = e3;
	}
	
	void printParseTree(String indent)
	{
		String indent1 = indent + " ";
		String indent2 = indent1 + " ";
		LexAnalyzer.displayln(indent + indent.length() + " <exp> ");
		LexAnalyzer.displayln(indent1 + indent1.length() + " if");
		expr1.printParseTree(indent2);
		LexAnalyzer.displayln(indent1 + indent1.length() + " then");
		expr2.printParseTree(indent2);
		LexAnalyzer.displayln(indent1 + indent1.length() + " else");
		expr3.printParseTree(indent2);
	}
	
	Val Eval(HashMap<String,Val> state) {
		if(expr1.Eval(state).toString().equalsIgnoreCase("true")||expr1.Eval(state).toString().equalsIgnoreCase("1"))
		{
			return expr2.Eval(state);
		}
		else if(expr1.Eval(state).toString().equalsIgnoreCase("false")||expr1.Eval(state).toString().equalsIgnoreCase("0"))
			return expr3.Eval(state);
		else 
			{
			System.out.println("Error: boolean condition of if-then-else evaluated to non-boolean value");
			LexAnalyzer.displayln("Error: boolean condition of if-then-else evaluated to non-boolean value");
			return null;
			
			}
			
	}
}

class Fun_Exp extends Exp
{
	static int pairs = 0;
	FunOp operator;
	ExpList exp_list;
	
	void printParseTree(String indent)
	{
		String indent1 = indent + ' ';
		LexAnalyzer.displayln(indent + indent.length() + " <exp> ");
		LexAnalyzer.displayln(indent1 + indent1.length() + " <fun exp>");
		indent1 = indent1 + ' ';
		operator.printParseTree(indent1);
		exp_list.printParseTree(indent1);

	}
	
	Val Eval(HashMap<String,Val> state)
	{
		System.out.println("1");
		
		return null;
	}

}

class Exp_Nil extends Exp
{
	void printParseTree(String indent)
	{
		String hold=indent +" ";
		LexAnalyzer.displayln(indent + indent.length() + " <exp> ");
		LexAnalyzer.displayln(hold + hold.length() + " " + "Nil");
	}	
	
	Val Eval(HashMap<String,Val> state) {return new NilVal("nil");}
}
